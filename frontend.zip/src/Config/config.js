import axios from 'axios'




export const BASE_URL = "http://localhost:4000"
export const sendRequest = async(segment, body, method)=>{
    const request = await axios({
        url: `${BASE_URL}${segment}`,
        data: body,
        method: method
    }).catch((e)=>({data: [], status: false, msg: e.message}))
    // console.log(`${BASE_URL}${segment}`, " From axios")
    return request.data
}