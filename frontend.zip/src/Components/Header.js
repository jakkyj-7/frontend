import { AppBar, Toolbar, Typography, Button,IconButton,  } from '@mui/material'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import {sendRequest} from '../Config/config'
import { Box } from '@mui/system'
import React, { useEffect } from 'react'


import {useDispatch, useSelector} from 'react-redux'
import * as creators from '../Store/ActionCreators/productAc'
import {bindActionCreators} from 'redux'
const pageButtons = ["Products", "Add Products"]
function Header() {
    const {addProduct, showCart, cartItems} = useSelector(store=>store.products)

    const dispatch = useDispatch()
    const {openAddProduct, openCartProduct, setCartProducts} = bindActionCreators(creators, dispatch)
    useEffect(()=>{
        getAllCartProducts()
    }, [])

    const getAllCartProducts = async()=>{
        const body = new FormData()
        const segment = "/getAllCartProducts"
        const response = await sendRequest(segment, body, 'POST')
        if(response['status']){
            setCartProducts({
                type: 'setcartproducts', payload: response['data']
            })
        }


    }

  return (
    <AppBar>
        <Toolbar disableGutters>
            <div style={{width: '5%'}}>

            </div>
        <Typography
            variant="h6"
            noWrap
            // component="a"
            // href="/"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            Online Cart
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {/* {
                pageButtons.map((ele, index)=>{
                    return( */}
                    <Button
                        // key={ele}
                        onClick={()=>{
                            
                        }}
                        sx={{ my: 2, color: 'white', display: 'block' }}
                    >
                        Products
                    </Button>
                    <Button
                        // key={ele}
                        onClick={()=>{
                            openAddProduct({type: 'addpro', payload: true})
                        }}
                        sx={{ my: 2, color: 'white', display: 'block' }}
                    >
                        Add Products
                    </Button>
                    {/* )
                })
            } */}
          </Box>
          <Box sx={{ flexGrow: 0 }} >
            <IconButton 
                style={{position: 'absolute', right: '3%', top: '25%'}}
            onClick={()=>{
                openCartProduct({type: 'showCart', payload: true})
            }} 
            sx={{ p: 0 }}>
                <div style={{position: 'absolute', top: '-15px'}}>
                    <Typography variant='body2' style={{color: 'white'}}>
                        {cartItems.length}
                    </Typography>
                </div>
                <ShoppingCartIcon style={{color: 'white'}}/>
            </IconButton>
          </Box>
        </Toolbar>
    </AppBar>
  )
}

export default Header