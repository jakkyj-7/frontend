import { Typography, Grid, Button, TextField } from '@mui/material'
import EditIcon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import React, {useEffect, useState} from 'react'
import { sendRequest } from '../Config/config';
import {useDispatch, useSelector} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as creators from '../Store/ActionCreators/productAc'

function Products() {
    const [sort, setSort] = useState(false)
    const {products} = useSelector((store)=>store.products)
    const dispatch = useDispatch()
    const {setProducts, setCartProducts} = bindActionCreators(creators, dispatch)
    const getProducts = async()=>{
        const response = await sendRequest('/getAllProducts', new FormData(), 'POST')
        if(!response['status']){
            return false
        }
        // console.log(response, " From Products")

        response['data'] = response['data'].map((ele)=>{
            ele['edit'] = false
            return ele
        })

        setProducts({
            type: 'setproducts', payload: response['data']
        })

    }
    useEffect(()=>{
        getProducts()
        console.log("Function calling")
    }, [])

    const deleteProducgt = async (proid)=>{
        if(!window.confirm("Are You Sure Want to Delete this item?")){
            return false
        }
        const body = new FormData()
        body.append('id', proid)
        const segment = "/deleteProduct"
        const respones = await sendRequest(segment, body, 'POST')
        alert(respones['msg'])
        if(respones['status']){
            await getProducts()
            await getAllCartProducts()
        }
    }

    const addToCart = async(obj)=>{
        // productName: productname,
        // productPrice: price,
        // productQuantity: productqty,
        // productImg: productimg,
        // id: new Date().getTime()
        const body = new FormData()
        const segment = "/addToCart"
        body.append('productname', obj['productName'])
        body.append('price', obj['productPrice'])
        body.append('productqty', obj['productQuantity'])
        body.append('productimg', obj['productImg'])
        body.append('id', obj['id'])
        const response = await sendRequest(segment, body, 'POST')
        // console.log(response)
        alert(response['msg'])
        if(response['status']){
           await getProducts()
           await getAllCartProducts()
        }


    }


    const getAllCartProducts = async()=>{
        const body = new FormData()
        const segment = "/getAllCartProducts"
        const response = await sendRequest(segment, body, 'POST')
        if(response['status']){
            setCartProducts({
                type: 'setcartproducts', payload: response['data']
            })
        }


    }


    const addProductToServer = async(pro)=>{
        const body = new FormData()
        body.append('productname', pro['productName'])
        body.append('price', pro['productPrice'])
        body.append('productqty', pro['productQuantity'])
        body.append('productimg', pro['productImg'])
        body.append('id', pro['id'])

        const segment = '/addProduct'
        const response = await sendRequest(segment, body, 'POST')
        alert(response['msg'])
        
        if(response['status']){
            // setPro({productname: '', productprice: '', productqty: '', productimg: ''})
            // openAddProduct({
            //     type: 'addpro', payload: false
            // })
            await getProducts()
            await getAllCartProducts()
            // console.log("first frommmm")
        }
    }

  return (
    <div style={{width: '100%',height: '90%', position: 'absolute', bottom: '0', backgroundColor: '#f5f4f4'}}>
        <div style={{position: 'relative', width: "80%", left: '10%', height: '95%',bottom: '0', backgroundColor: 'white', paddingTop: '2%', boxShadow: '0px 4px 8px #888888', overflow: 'scroll'}}>
            <div style={{width: "100%", display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
                <Typography variant='h5' style={{marginLeft: '10px'}}>
                    Products
                </Typography>
                <Button variant='contained' color='primary' onClick={()=>{
                    setSort((prev)=>!prev)
                }} endIcon={sort ? <ArrowDownwardIcon color='white'/> : <ArrowUpwardIcon color='white'/>}>Price Sort </Button>
            </div>

            <Grid container spacing={2} style={{width:"100%", padding: '10px', margin: '0'}}>
                {
                   products != undefined && products.length > 0 && [...products].sort((a, b)=>{
                        if(sort){
                            if(parseInt(a['productPrice']) > parseInt(b['productPrice'])){
                                return 1
                            }

                            if(parseInt(a['productPrice']) < parseInt(b['productPrice'])){
                                return -1
                            }

                            return 0
                        }else{
                            if(parseInt(a['productPrice']) < parseInt(b['productPrice'])){
                                return 1
                            }

                            if(parseInt(a['productPrice']) > parseInt(b['productPrice'])){
                                return -1
                            }

                            return 0
                        }
                   }).map((element, index)=>{
                        return(
                            <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}} >
                                <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                                    {
                                        !element['edit'] &&
                                        <>
                                            <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}} onClick={()=>{deleteProducgt(element['id'])}}/>
                                            <EditIcon style={{cursor: 'pointer', color: 'blue'}} onClick = {()=>{
                                                // alert(index)
                                                const proInd = products.findIndex(ele=>ele['id'] == element['id'])
                                                products[proInd]['edit'] = true
                                                // console.log(products)
                                                setProducts({
                                                    type: 'setproducts', payload: [...products]
                                                }) 
                                            }}/>
                                        </>
                                    }
                                    
                                </div>
                                
                                <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                                
                                    {/* Product Name */}
                                    {
                                        element['edit'] ? <TextField value={element['productName']} onChange={(e)=>{
                                            const proInd = products.findIndex(ele=>ele['id'] == element['id'])
                                            products[proInd]['productName'] = e.target.value
                                            setProducts({
                                                type: 'setproducts', payload: products
                                            })
                                        }} style={{width: "120px"}}/> : <Typography variant='body1' style={{fontWeight: '700'}}>{element['productName']}</Typography>
                                    }
                                    
                                
                                {/* <Typography variant='body2'> */}
                                    qty left:- {
                                    element['edit'] ? <TextField style={{width: '50px'}} onChange={(e)=>{
                                        const proInd = products.findIndex(ele=>ele['id'] == element['id'])

                                        products[proInd]['productQuantity'] = e.target.value
                                            setProducts({
                                                type: 'setproducts', payload: products
                                            })
                                    }} value = {element['productQuantity']}/> :
                                    element['productQuantity']}
                                {/* </Typography> */}
                                </div>
                                
                                <div style={{width: "100%", height:"150px"}}>
                                    {
                                        element['edit'] ? <TextField value = {element['productImg']} onChange={(e)=>{
                                            const proInd = products.findIndex(ele=>ele['id'] == element['id'])

                                            products[proInd]['productImg'] = e.target.value
                                            setProducts({
                                                type: 'setproducts', payload: products
                                            })
                                        }}/>
                                        :

                                    <img src={element['productImg']} width={'100%'} height={'100%'}/>
                                    }
                                </div>
                            <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                                    
                                <Button variant='contained' size='small' color='primary' onClick={()=>{
                                    if(element['edit']){
                                        addProductToServer(element)
                                    }else{
                                        addToCart(element)
                                    }
                                }}>{element['edit'] ? 'Update': 'Add to cart'}</Button><br/>
                                {/* <Typography variant='body2'> */}
                                    Rs {
                                    element['edit'] ? <TextField value = {element['productPrice']} onChange={(e)=>{
                                        const proInd = products.findIndex(ele=>ele['id'] == element['id'])

                                        products[proInd]['productPrice'] = e.target.value
                                            setProducts({
                                                type: 'setproducts', payload: products
                                            })
                                    }} style={{width: '70px'}}/>:
                                    element['productPrice']}/-
                                {/* </Typography><br/> */}
                                </div>
                            </Grid>
                        ) 
                   })
                }

                {
                    products != undefined && products.length == 0 && 
                    <div style={{textAlign: 'center', width: '100%'}}>
                        <Typography variant='body2' style = {{color: "red"}}>
                        No Data Found 
                    </Typography>
                    </div>
                    
                }

                {/* <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid>


                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid>
                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid>
                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid>
                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid>
                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                    <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                        <DeleteForeverIcon style={{cursor: 'pointer', color: 'red'}}/>
                        <EditIcon style={{cursor: 'pointer', color: 'blue'}}/>
                    </div>
                    
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                    <Typography variant='body1' style={{fontWeight: '700'}}>
                        Product Name
                    </Typography>
                    <Typography variant='body2'>
                        qty left:- 20
                    </Typography>
                    </div>
                    
                    <div style={{width: "100%", height:"150px"}}>
                        <img src='https://m.media-amazon.com/images/S/aplus-media-library-service-media/0db4c16f-22c8-4c07-80fb-d3c4b970dd0f.__CR0,0,1080,1080_PT0_SX300_V1___.jpg' width={'100%'} height={'100%'}/>
                    </div>
                   <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>

                   
                    <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/>
                    <Typography variant='body2'>
                        Rs 500/-
                    </Typography><br/>
                    </div>
                </Grid> */}

                
            </Grid>

        </div>
    </div>
  )
}

export default Products