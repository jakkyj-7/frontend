import React from 'react'
import AddProduct from './AddProduct'
import CartProducts from './CartProducts'
import Header from './Header'
import Products from './Products'

function Home() {
  return (
    <>
        <Header/>
        <Products/>
        <AddProduct/>
        <CartProducts/>
    </>
  )
}

export default Home