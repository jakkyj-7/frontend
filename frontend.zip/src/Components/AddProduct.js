import React, { useState } from 'react'
import CloseIcon from '@mui/icons-material/Close';
import { TextField, Typography, Grid, Button } from '@mui/material';
import {useSelector, useDispatch} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as creators from '../Store/ActionCreators/productAc'
import { sendRequest } from '../Config/config';
function AddProduct() {
    const [pro, setPro] = useState(()=>({productname: '', productprice: '', productqty: '', productimg: ''}))


    const {addProduct} = useSelector(store=>store.products)
    const dispatch = useDispatch()
    const {openAddProduct, setProducts} = bindActionCreators(creators, dispatch)
    const getAllProducts = async ()=>{
        const response = await sendRequest('/getAllProducts', new FormData(), 'POST')
        if(!response['status']){
            return false
        }
        // console.log(response, "  from add product")
        response['data'] = response['data'].map((ele)=>{
            ele['edit'] = false
            return ele
        })
        setProducts({
            type: 'setproducts', payload: response['data']
        })
    }
    const addProductToServer = async()=>{
        const body = new FormData()
        body.append('productname', pro['productname'])
        body.append('price', pro['productprice'])
        body.append('productqty', pro['productqty'])
        body.append('productimg', pro['productimg'])
        body.append('id', -1)

        const segment = '/addProduct'
        const response = await sendRequest(segment, body, 'POST')
        alert(response['msg'])
        
        if(response['status']){
            setPro({productname: '', productprice: '', productqty: '', productimg: ''})
            openAddProduct({
                type: 'addpro', payload: false
            })
            await getAllProducts()
            // console.log("first frommmm")
        }
    }

    

    // console.log(addProduct)
  return (
    addProduct ? 
    <div style={{
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0, 0.7)',
        zIndex: 999999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }}>
        <div style={{
            width: '50%',
            height: '50%',
            backgroundColor: 'white',
            borderRadius: '5px',
            position: 'relative',
           
        }}>
            <div style={{ display:'flex',
            alignItems: 'center',
            justifyContent: 'space-between'}}>
            <Typography variant='h6' style={{position: 'absolute', top:'10px', left: '10px'}}>
                Add Product
            </Typography>
            <div style={{position: 'absolute', right: '10px', top:'10px', borderRadius: '5px', backgroundColor: 'red', width: '50px', height: '50px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center'}} onClick={()=>{
                openAddProduct({type: 'addpro', payload: false})
            }}>
                <CloseIcon style={{color: 'white'}}/>
            </div>
            </div>
            <Grid container spacing={2} style={{position: 'relative', top: '30%', padding: '5px'}}>
                <Grid  item xs={4}>
                    <TextField label='Product Name' name='productname' value = {pro['productname']} onChange={(e)=>{setPro((prev)=>({...prev, [e.target.name]: e.target.value}))}} type={'text'} variant='outlined'/>
                </Grid>
                <Grid  item xs={4}>
                    <TextField label='Price' type={'number'} variant='outlined' name="productprice" value = {pro['productprice']} onChange={(e)=>{setPro((prev)=>({...prev, [e.target.name]: e.target.value}))}}/>
                </Grid>
                <Grid  item xs={4}>
                    <TextField label='Product Qty' type={'number'} variant='outlined' onChange={(e)=>{setPro((prev)=>({...prev, [e.target.name]: e.target.value}))}} name = "productqty" value={pro['productqty']}/>
                </Grid>
                <Grid  item xs={12}>
                    <TextField label='Image Url' type={'text'} name="productimg" variant='outlined' style={{width: '100%'}} value={pro['productimg']}
                        onChange={(e)=>{setPro((prev)=>({...prev, [e.target.name]: e.target.value}))}}
                    InputLabelProps={{
                        shrink: true
                    }}/>
                </Grid>
                <Grid  item xs={12}>
                    <Button variant="contained" color='primary' onClick={addProductToServer}>
                        Submit
                    </Button>
                </Grid>
            </Grid>
        </div>
    </div>:
    <></>
  )
}

export default AddProduct