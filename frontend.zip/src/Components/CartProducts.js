import { Typography, Grid, Button } from '@mui/material'
import EditIcon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import CloseIcon from '@mui/icons-material/Close';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { sendRequest } from '../Config/config';
import React, { useEffect } from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as creators from '../Store/ActionCreators/productAc'

function CartProducts() {
    const {addProduct, showCart, cartItems} = useSelector(store=>store.products)

    const dispatch = useDispatch()
    const {openCartProduct, setCartProducts, setProducts} = bindActionCreators(creators, dispatch)
    useEffect(()=>{
        getAllCartProducts()
    }, [])

    const getProducts = async()=>{
        const response = await sendRequest('/getAllProducts', new FormData(), 'POST')
        if(!response['status']){
            return false
        }
        // console.log(response, " From Products")
        response['data'] = response['data'].map((ele)=>{
            ele['edit'] = false
            return ele
        })
        setProducts({
            type: 'setproducts', payload: response['data']
        })

    }


    const getAllCartProducts = async()=>{
        const body = new FormData()
        const segment = "/getAllCartProducts"
        const response = await sendRequest(segment, body, 'POST')
        console.log(response, " From cartproducts")
        if(response['status']){
            setCartProducts({
                type: 'setcartproducts', payload: response['data']
            })
        }


    }

    const removeItemFromCart = async(id)=>{
        if(!window.confirm("Are You Sure Want to Remove this Item")){
            return false
        }
        const body = new FormData()
        const segment = '/removeCartItem'
        body.append('id', id)
        const response = await sendRequest(segment, body, 'POST')
        alert(response['msg'])
        if(response['status']){
            await getAllCartProducts()
            await getProducts()
        }


    }

  return (
    showCart ? 
    <div
    style={{
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0, 0.7)',
        zIndex: 999999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'}}
    >
        <div style={{width: '90%',height: '90%', position: 'absolute', backgroundColor: '#f5f4f4'}}>
        <div style={{position: 'absolute', right: '10px', top:'10px', borderRadius: '5px', backgroundColor: 'red', width: '50px', height: '50px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center'}} onClick={()=>{
            openCartProduct({type: 'showCart', payload: false})
        }}>
                <CloseIcon style={{color: 'white'}}/>
            </div>
            <div style={{position: 'relative', width: "80%", left: '10%', height: '95%',bottom: '0', backgroundColor: 'white', paddingTop: '2%', boxShadow: '0px 4px 8px #888888', overflow: 'scroll'}}>
                <Typography variant='h5'>
                   Cart Products
                </Typography>

                <Grid container spacing={2} style={{width:"100%", padding: '10px', margin: '0'}}>

                    {
                        cartItems != undefined && cartItems.length > 0 && 
                        cartItems.map((element, index)=>{
                            return (
                                <Grid container item xs = {3} style={{width: '95%', height: "300px", border: '1px solid #d7d2d2', borderRadius: '5px', padding: "15px"}}>
                                <div style={{width: '100%', padding: '8px', display: 'flex', flexDirection: 'row-reverse'}}>
                                            <HighlightOffIcon style={{cursor: 'pointer', color: 'red'}} onClick={()=>{
                                                removeItemFromCart(element['id'])
                                            }}/>
                                            {/* <EditIcon style={{cursor: 'pointer', color: 'blue'}}/> */}
                                        </div>
                                        
                                        <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                                        <Typography variant='body1' style={{fontWeight: '700'}}>
                                        {element['productname']}
                                        </Typography>
                                        <Typography variant='body2'>
                                            qty:- {element['productqty']}
                                        </Typography>
                                        </div>
                                        
                                        <div style={{width: "100%", height:"150px"}}>
                                            <img src={element['productimg']} width={'100%'} height={'100%'}/>
                                        </div>
                                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%'}}>
                
                                    
                                        {/* <Button variant='contained' size='small' color='primary'>Add to cart</Button><br/> */}
                                        <Typography variant='body2'>
                                            Rs {element['price']}/-
                                        </Typography><br/>
                                        </div>
                                    </Grid>
                            )
                        })
                    }

                    


                    {
                        cartItems!= undefined && cartItems.length == 0 &&
                        <div style={{width: '100%', textAlign: 'center'}}>
                            <Typography variant='body2' style={{color: 'red'}}>No Item Added To Cart</Typography>
                        </div>
                    }

                    

                    
                </Grid>

            </div>
        </div>
    </div>
    :<></>
    
  )
}

export default CartProducts