const datastore = {
    addProduct: false,
    showCart: false,
    products: [],
    cartItems: []
}

export const productReducer = (store=datastore, action)=>{
    switch (action.type) {
        case 'addpro':
            return {...store, addProduct: action.payload}
            
        case 'showCart':
            return {...store, showCart: action.payload}
        
        case 'setproducts': 
            return {...store, products: action.payload}

        case 'setcartproducts':
            return {...store, cartItems: action.payload}
        default:
            return {...store};
    }
}