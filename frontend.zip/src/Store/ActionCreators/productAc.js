export const openAddProduct = (data)=>{
    return (dispatch)=>{
        // alert("hi")
        dispatch({
            ...data
        })
    }
}
export const openCartProduct = (data)=>{
    return (dispatch)=>{
        
        dispatch({
            ...data
        })
    }
}


export const setProducts = (data)=>{
    return (dispatch)=>{
        dispatch({...data})
    }
}

export const setCartProducts = (data)=>{
    return (dispatch)=>{
        dispatch({...data})
    }
}